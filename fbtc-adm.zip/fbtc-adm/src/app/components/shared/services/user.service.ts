import { Injectable } from '@angular/core';

@Injectable()
export class UserService {
    userName: string = 'Fulano de Tal da Silva';
}

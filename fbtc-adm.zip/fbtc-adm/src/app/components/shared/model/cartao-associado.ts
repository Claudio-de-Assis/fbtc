export class CartaoAssociado {
    CartaoAssociadoId: number;
    ColaboradorId: number;
    AssociadoId: number;
    DtEmissao: Date;
}

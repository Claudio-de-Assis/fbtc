export class Isencao {
    isencaoId: number;
    anuidadeId: number;
    eventoId: number;
    descricao: string;
    dtAta: Date;
    anoEvento: number;
    tipoIsencao: string;
    ativo: boolean;
}

export class AssociadoIsento {
    AssociadoIsentoId: number;
    DtCadastro: Date;
    AtaIsencaoId: number;
    AssociadoId: number;
}

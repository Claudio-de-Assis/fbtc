import { Pessoa } from './pessoa';

export class Colaborador extends Pessoa {
    colaboradorId: number;
    tipoPerfil: string;
}

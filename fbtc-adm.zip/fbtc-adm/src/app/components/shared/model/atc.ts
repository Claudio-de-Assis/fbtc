export class Atc {
    atcId: number;
    nome: string;
    uf: string;
    nomePres: string;
    nomeVPres: string;
    nomePSec: string;
    nomeSSec: string;
    nomePTes: string;
    nomeSTes: string;
    site: string;
    siteDiretoria: string;
    ativo: boolean;
}

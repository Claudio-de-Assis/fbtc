export class Anuidade {
    Anuidade: number;
    DtCadastro: Date;
    Codigo: number;
}

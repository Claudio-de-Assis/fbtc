export class ValorEventoPublico {
    ValorEventoPublicoId: number;
    EventoId: number;
    Valor: number;
    TipoPublicoId: number;
}

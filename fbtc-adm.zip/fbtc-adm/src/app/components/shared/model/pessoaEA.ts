export class PessoaEA {
    PessoaId: number;
    Nome: string;
    CPF: string;
    NrCelular: string;
    EMail: string;
    Sexo: string;
    NomeFoto: string;
    DtNascimento: Date;
    PasswordHash: string;
    DtCadastro: Date;
    Ativo: boolean;
    TipoPessoa: string;
}

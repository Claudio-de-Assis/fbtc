export class ParametroAdimplencia {
    ParametroAdimplenciaId: number;
    NotificarVencAnuidade: boolean;
    NotificarVencEventos: boolean;
    EnviarBoletoEMail: boolean;
    QtdDias: number;
}

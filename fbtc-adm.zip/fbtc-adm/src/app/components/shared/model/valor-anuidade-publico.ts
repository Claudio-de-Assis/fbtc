export class ValorAnuidadePublico {
    ValorAnuidadePublicoId: number;
    valor: number;
    AnuidadeId: number;
    TipoPublicoId: number;
}
